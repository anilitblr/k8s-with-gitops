sample Kubernetes app for use in GitOps course. See also https://github.com/sandervanvugt/gitops
